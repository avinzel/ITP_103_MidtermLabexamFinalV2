package com.example.demo;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Task 5: Error Handling
 * Final stage of the pipeline. Simulates occasional system downtime (~30% of runs),
 * retries up to 3 times, and if retries are exhausted, routes the application to
 * a manual review queue instead of losing it. Otherwise the permit is approved.
 */
@Component
public class Task5ErrorHandlingRoute extends RouteBuilder {

    @Autowired
    private LogStore logStore;

    @Override
    public void configure() throws Exception {

        onException(Exception.class)
            .maximumRedeliveries(3)
            .redeliveryDelay(1000)
            .handled(true)
            .log("Retries exhausted, sending to manual review: ${body}")
            .process(exchange -> logStore.add("Task 5: FLAGGED for manual review - " + exchange.getIn().getBody(String.class)))
            .to("seda:manualReviewQueue");

        from("seda:finalizePermit")
            .routeId("task5-finalize")
            .process(exchange -> {
                if (Math.random() < 0.3) {
                    throw new RuntimeException("Simulated permit system downtime");
                }
            })
            .log("PERMIT APPROVED: ${body}")
            .process(exchange -> logStore.add("Task 5: PERMIT APPROVED - " + exchange.getIn().getBody(String.class)));

        from("seda:manualReviewQueue")
            .routeId("task5-manualReview")
            .log("Manual review received: ${body}");
    }
}
